def closestDivisorSumList(x):
    """
    closestDivisorSumList는 x값을 input으로 받아서 먼저 prodiv라는 list에 properdivisor들을 담고, 그 부분집합들을 구하고 그 요소들의 합과 x의 차이가
    최소가 되는 부분집합을 result로 return하는 함수이다.
    """
    prodiv = []  # 비어있는 list를 생생하고 할당하였으며 proper divisor들의 집합을 나타낸다.

    for i in range(1, x // 2 + 1):  # proper divisor의 list를 생성할 것이므로 x의 절반까지만 확인한다.
        if x % i == 0:  #만약 x가 i로 나누어 떨어진다면, proper divisor의 조건을 만족한다.
            prodiv.append(i)   #prodiv라는 리스트에 proper divisor들을 넣는다.

    nearestsum = sum(prodiv)  # 가장 x값과 가까운 sum의 값으로, 초기에는 prodiv의 sum값으로 초기화
    smallestdiff = abs(nearestsum - x)  # nearest 와 x의 가장 작은 차이값으로, 초기에는 nearestsum과 x값의 차이로 초기화
    result = prodiv  # sum이 가장 x에 가까울 떄의 list로, 즉 result list로, 초기에는 prodiv로 초기화


    subsets = [[]]  #subsets라는 list를 만들어서 부분집합들을 집어넣는다.

    for element in prodiv:  #prodiv안에 있는 인수들에 대해서 반복한다.
        new_subsets = [subset + [element] for subset in subsets]  # prodiv안에 있는 요소를 순회하면서 새로운 요소를 추가한 부분집합 생성
        subsets.extend(new_subsets)  # 기존 부분집합에 추가하여 전체 부분집합 업데이트

    for subset in subsets:  #subsets 안에 있는 subset들에 대해서 반복
        subset_sum = sum(subset)    #sum함수를 이용하여 subset의 요소들의 합을 계싼
        #subset_sum과 x값의 차이의 절대값 계산
        if subset_sum >= x:
            diff=subset_sum-x
        elif subset_sum < x:
            diff=x-subset_sum
        # 위에서 계산된 diff값이 smallestdiff값보다 작다면 그 subset이 result가 됨.
        if diff < smallestdiff:
            nearestsum = subset_sum #nearestsum도 subset_sum으로 업데이트
            smallestdiff = diff #smallestdiff도 diff값으로 업데이트
            result = subset

    return result