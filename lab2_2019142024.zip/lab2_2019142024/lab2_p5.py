def myPiCalculator(tol):    #tol이라는 값을 input으로 받아 pi의 값을 어림잡아 계산한다.
    """myPiCalculator함수는 tol이라는 오차범위값을 input으로 받고 그 범위에 맞는 pi값을 어림잡아 계산한다. 그 방식은 2로 시작하는 pi의
    base에 term들을 곱하여 pinew를 구하고 pinew와 pi의 차의 절댓값이 tol이 넘지 않을 떄까지 그 과정을 반복하여 pi의 근사값을 계산한다."""

    pi=2    #pi의 base는 2로 시작한다.
    pinew=0 #pinew는 0으로 초기화하였다. 후에 값이 할당된다.
    termdenom=2**0.5    #pi에 term들을 곱하여 pinew가 바뀌는데, term의 분모들을 계산하기 위해 초기 분모를 이와 같이 설정한다.
    abdif=100   #while문에 들어가기 위해 abdif값을 초기화하였는데, 파이값이 3.14근처이므로 100으로 설정하면 충분히 tol값보다 크다.
    while abdif >= tol: #차이의 절댓값이 tol보다 클 때 loop를 실행시킨다.
        pinew=pi*(2/termdenom)  #pinew값은 pi에 2/termdenom을 곱하여 계산
        if pi >= pinew: #차의 절댓값 계산, 만약 pi가 더 크거나 같을 경우
            abdif = pi - pinew  #차의 절댓값은 pi-pinew
        elif pi < pinew:    #만약 pinew가 더 클 경우
            abdif = pinew - pi  #차의 절댓값으 pinew-pi
        pi=pinew    #pi에 pinew값을 할당한다.
        termdenom=(2+termdenom)**0.5    #termdenom값은 각 term의 분모로 그 전 termdenom에 2를 더하고 루트를 씌운것과 같다.

    return pinew    #pinew값을 결과값으로 return한다.
