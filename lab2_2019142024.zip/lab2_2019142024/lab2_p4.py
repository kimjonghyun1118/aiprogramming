def evalPolynomial(x, L):   #x라는 변수 값과 L이라는 list를 받는다.
    """evalPolynomial이라는 함수는 x라는 변수값과 L이라는 list를 받는다. L의 각 인수들은 다항식의 각 coefficient로, 각 차수의 계수로써
    곱해져서 다항식의 결과를 계산한다."""

    result = 0  #먼저 결과롤 출력한 result값을 0으로 초기화한다.
    for i in range(len(L)): #len(L)이라는 L의 list의 길이만큼 반목한다.
        item = L[i] #item이라는 변수에 리스트의 각 인수들을 저장한다.
        result = result + item*(x**i)   #item이라는 coefficient에 x의 i제곱을 곱하고, 그 값을 result값에 더한다.

    return result   #결과적으로 result값은 다항식의 계산결과가 된다.