def resetValues(L,t):   #먼저 resetValues라는 funciton을 정의하고 L이라는 list와 t라는 int형 숫자를 input으로 갖는다.
    """이 함수는 리스트와 정수를 input으로 받아 t보다 작거나 같은 인수만을 result list로 보내는 역할을 수행한다."""
    Result = [] #result값으로 출력할 list를 선언한다.
    for x in L: #list L안에 있는 인수 x에 대하여 반복한다.
        if x <= t:  #만약 x가 t보다 작거나 같을 때에만 실행한다.
            Result.append(x)    #결과가 되는 list에 x값을 집어 넣는다. 이때 L을 변화시키지 않기 위해 append를 사용했다.

    return Result   #Result라는 결과 list를 출력한다.