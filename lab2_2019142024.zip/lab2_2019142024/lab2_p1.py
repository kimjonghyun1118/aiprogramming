size = int(input("Enter a size: ")) #size를 int형 input으로 사용자로부터 받는 코드

dir = input("Enter a direction: ")  #이번에는 삼각형 모양으로 input으로 받는 코드, 자동으로 str형으로 받아진다
if dir == "u":  # 방향이 u일 떄
    for i in range(1, size+1, 1):   #높이와 size가 같으므로 i=1부터 시작해서 size만큼 반복한다.
        print(" "*(size-i)+"*"*(2*i-1)) #띄어쓰기는 size에서 시작하여 i만큼 줄어들고, *은 홀수로 1부터 증가한다.

elif dir == "d":    #방향이 d일 때
    for i in range(1, size+1, 1):   #높이가 size와 같으므로 i=1부터 시작해서 size만큼 반복한다.
        print(" "*(i-1)+"*"*(2*size-2*i+1)) #이번에는 띄어쓰기 개수는 0부터 시작하여 1씩 증가하고, *은 2*size-1에서 홀수로 감소한다.

elif dir == "l":    #방향이 l일 때
    for i in range(1, size+1, 1):   #높이가 size일 때까지 정의
        print(" "*(size-i)+"*"*i)   #띄어쓰기 개수가 size-1에서 하나씩 줄어들고, *개수는 1부터 하나씩 증가한다.
    for i in range(1, size, 1): #그 밑으로 삼각형 모양 정의
        print(" "*i+"*"*(size-i))

elif dir == "r":    #방향이 r일 때
    for i in range(1, size+1, 1):   #높이가 size일 때까지 정의
        print("*"*i)    #*의 개수가 1개서부터 하나씩 증가
    for i in range(1, size, 1): #그 밑으로 삼각형 모양 정의
        print("*"*(size-i)) #*의 개수가 최대치를 찍고 하나씩 감소
