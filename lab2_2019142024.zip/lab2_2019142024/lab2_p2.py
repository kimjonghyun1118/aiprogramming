number = int(input("Up to which number to print?: "))   #어떤 숫자까지 표시할건지 int형으로 input을 받는다.
quot = number // 10     #10으로 나눈 몫을 구한다.
remain = number % 10    #10으로 나눈 나머지를 구한다.
if number > 9:  #먼저, 2자리 이상의 숫자가 들어올 경우
        for j in range(1,11,1):         #j는 1의 자리, i는 10의 자리를 나타낸다. j는 1부터 10까지 증가하며 반복
                if j <= remain: #j가 remain보다 작거나 같을 경우
                        for i in range(0, quot+1, 1):   #j가 remain보다 작을 때는 10자리가 0부터 quot까지 규칙에 맞게 출력
                                if 10*i+j < 10: #만약 1의 자리 숫자일 경우
                                        print("  "+str(10*i+j), end="") #띄어쓰기를 두번 print하고 숫자를 str형으로 출력한다.

                                elif 9 < 10*i+j < 100:  #만약 두자리 숫자일 경우
                                        print(" "+str(10*i+j), end="")  #띄어쓰기를 한번만 출력하고 숫자를 출력한다.

                                elif 100 < 10*i+j:      #세자리 숫자일 경우
                                        print(10*i+j, end="")   #띄어쓰기를 출력하지 않는다. 각각의 경우에 줄바꿈이 없도록 한다.
                else:   #만약 j가 remain보다 클 경우
                        for i in range(0, quot, 1):     #10의 자리로 0부터 quot-1까지만 출력
                                if 10 * i + j < 10:     #한자리 숫자일 경우
                                        print("  " + str(10 * i + j), end="")   #띄어쓰기를 2번 출력하고 숫자를 출력

                                elif 9 < 10 * i + j < 100:      #두자리숫자일 경우
                                        print(" " + str(10 * i + j), end="")    #띄어쓰기를 1번 출력하고 숫자를 출력

                                elif 99 < 10 * i + j:   #세자리 숫자일 경우
                                        print(10 * i + j, end="")       #띄어쓰기 없이 숫자를 출력
                print() #각 줄을 출력한 후 줄바꿈 한번
elif number < 10:       #만약 입력된 숫자가 한자리 숫자일 경우
        for k in range(1,number+1,1):   #1부터 숫자까지 줄바꾸면서 출력
                print(k)


