
firstfile=input("Enter the filename: ") #filename을 변수에 저장한다.
first = open(firstfile, 'r')    #read모드로 file을 찾아 읽은 후 first에 넣는다.

text = first.read()
while True:
    changed=input("What to change? ('quit' to quit): ") #변경될 문자가 무엇인지 input으로 받는다.
    if changed=="quit":     #만약 quit라는 input이 들어오면 while문을 탈출한다.
        break
    change=input("Change "+changed+" to what?: ")   #어떤 문자로 변경할지 input으로 받는다.
    text=text.replace(changed, change)  #replace문을 이용하여 text에서 변경될 문자를 변경한다.

lastfile=firstfile[:-4]+'_modified.txt' #file이름을 바꾸기 위해 slicing을 이용하여 변경한다.
last = open(lastfile, 'w')  #write모드로 lastfile이라는 file을 불러온다.
last.write(text)    #last에 text를 채워 넣는다.

print('File saved:',lastfile)
