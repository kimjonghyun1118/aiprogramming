import math

taxableincome=int(input("Enter the taxable income in USD: "))   #taxableincome을 정수형 input으로 받으며 문구를 출력한다.
tax=0   #tax를 0으로 초기화한다.
if taxableincome<=750:  #만약 income이 750이하일때
    tax=0.02*taxableincome  #tax는 income의 2%
elif 751<=taxableincome<=2250:  #income이 751이상, 2250이하일 때
    tax=7.50+0.03*(taxableincome-750)   #7.50USD에 750이상의 income값의 3%를 더한 값이 tax
elif 2251<=taxableincome<=3750: #income이 2251이상, 3750이하일 때
    tax=37.50+0.06*(taxableincome-2250)   #37.50USD에 2250이상의 income값의 6%를 더한 값이 tax
elif 3751<=taxableincome<=5250: #income이 3751이상, 5250이하일 때
    tax=82.50+0.09*(taxableincome-3750)  #82.50USD에 3750이상의 income값의 9%를 더한 값이 tax
elif 5251<=taxableincome<=7000: #income이 5251이상, 7000이하일 때
    tax=0.03*taxableincome+0.10*(taxableincome-5250)  #income의 3%에 5250이상의 income값의 10%를 더한 값이 tax
elif 7000<taxableincome: #income이 7000이상일 때
    tax=0.04*taxableincome+0.12*(taxableincome-7000)  #income의 12%에 7000이상의 income값의 12%를 더한 값이 tax

roundedtax=round(tax)   #위의 if문에서 구한 tax값을 정수가 되도록 반올림한다.
print("Tax due: ",end='')   #print문
print(roundedtax,end='')
print(" USD")

finalincome=taxableincome-roundedtax    #finalincome의 경우 taxableincome에서 반올림된 tax값을 빼주어서 산출
print("Final income:",finalincome,"USD")

