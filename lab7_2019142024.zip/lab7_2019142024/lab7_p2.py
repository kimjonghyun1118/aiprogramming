def lookAndSaySequence(n,l):
    """ n값을 list로 변환한 후, 길이 l을가지는 n값의 각 숫자의 개수를 나타내는 수를 list로 보내는 함수 """
    list = []   #비어있는 list 생성
    k = 1   #k값 초기화
    digit = 0   #digit값 초기화(n의 자릿수를 의미함)
    value = 0   #value값 초기화

    while True:     #n의 자릿수를 구하기 위한 while문
        value = n / k   #n을 k로 나눈값을 value로 할당
        k = k * 10  #k값을 while문이 한번 돌 때마다 10을 곱해줌
        digit = digit + 1   #while문이 한번 돌 때마다 digit값에 1을 더해줌
        if value < 10:  #만약 n을 k로 나눠준 값인 value가 10보다 작다면 가장 큰 자릿수가 나타났다는 의미이므로 break
            break

    for i in range(digit):  #정수인 n을 각 자릿수를 인수로 가지는 list로 변환함
        k = n // 10 ** (digit - i - 1)  #k는 각각 정수를 구성하는 숫자 하나하나를 의미함(가장 먼저 자릿수가 가장 높은 숫자부터 출력됨)
        list.append(k)  #구한 숫자 k를 list에 보냄
        n = n - (k) * (10 ** (digit - i - 1))   #남은 숫자는 가장 높은 자릿수를 뺀 나머지 숫자로 만들어줌

    finallist = []  #최종적으로 들어갈 숫자들의 list를 초기화함
    numlist=0   #finallist에 들어갈 인수들을 list에서 정수로 만들어주는 과정, 먼저 numlist를 0으로 초기화
    for i in range(len(list)):
        numlist=numlist+list[len(list)-i-1]*(10**i) #list의 인수에 각 자릿수에 해당하는 10의 제곱수를 곱해주고 이를 numlist에 더함
    finallist.append(numlist)   #구한 숫자를 finallist에 보냄
    newewlist = []  #newewlist라는 newlist를 잠시 저장한 list를 초기화함
    newlist = list  #list의 각 자리 숫자의 개수를 센 newlist

    for i in range(l - 1):  #첫번째는 list이므로 l-1번만큼 반복한다.
        for j in range(10): #0부터 9까지 반복하면서 newlist안에 있는 숫자의 개수를 센다
            count = newlist.count(j)    #그 개수를 count라는 변수에 할당

            if count != 0:      #만약 count가 0이 아니면, 즉, 하나라도 있으면 아래 if문 실행
                newewlist.append(count) #먼저 개수를 newewlist에 보냄
                newewlist.append(j) #다음으로 그 수를 newewlist에 보냄
        newlist = newewlist #만들어진 newewlist를 newlist에 할당
        numnewlist=0    #newlist에 할당했으므로 newewlist는 0으로 초기화(0으로 초기화해야 또 다시 처음부터 append할 수 있음)
        for q in range(len(newlist)):   #마찬가지로 list형태인 newlist를 정수로 만들어주는 과정
            numnewlist = numnewlist+newlist[len(newlist) - q - 1] * (10 ** q)
        finallist.append(numnewlist)    #정수화된 numnewlist를 finallist에 보내줌
        newewlist = []

    cycle=False #cycle값은 False로 설정
    for i in range(len(finallist) - 1): #finaliist보다 1작은 값만큼 반복하면서 만약 i번째 finnallist값과 그 다음 값이 일치할경우 cycle값을 True로 바꿔줌
        if finallist[i] == finallist[i + 1]:
            cycle = True


    return finallist, cycle


