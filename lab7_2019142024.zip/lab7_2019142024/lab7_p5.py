import math


class Point:
    """2D Euclidean coordinate"""

    def __init__(self, x, y):
        """Initialization"""
        self.x = round(x, 2)
        self.y = round(y, 2)

    def __str__(self):
        """"""
        return f"({self.x:.2f}, {self.y:.2f})"

    def __add__(self, other):
        """P1 + P2"""
        return Point(self.x + other.x, self.y + other.y)

    def __neg__(self):
        """Negation (-P1)"""
        return Point(-self.x, -self.y)

    def __sub__(self, other):
        """P1 - P2"""
        return Point(self.x - other.x, self.y - other.y)

    def __mul__(self, other):
        """Note: other is int or float"""
        if isinstance(other, float) or isinstance(other, int):
            return Point(other * self.x, other * self.y)
        else:
            raise ValueError("other should be type float or int")

    def __rmul__(self, other):
        """int * P1"""
        return self.__mul__(other)

    def __truediv__(self, other):
        """Note: other is int or float"""
        if isinstance(other, float) or isinstance(other, int):
            if other != 0:
                return Point(self.x / other, self.y / other)
            else:
                raise ZeroDivisionError("other should be non-zero")
        else:
            raise ValueError("other should be type float or int")

    ### Your work begins here ...

    def symmetric(self, reference_point):
        #평균 식을 활용하여 대칭인 점의 좌표를 구하는 함수
        newx=reference_point.x*2-self.x #대칭인 점은 x좌표의 평균이므로 식에 따라 x좌표를 구한다.
        newy=reference_point.y*2-self.y #대칭인 점은 y좌표의 평균이므로 식에 따라 y좌표를 구한다.
        return Point(newx,newy)

    def rotate(self, reference_point, angle):
        #회전 관계식에 따라 기준점으로부터 회전한 점의 좌표를 계산하는 함수.

        selfdifx=self.x-reference_point.x   #원점을 기준으로 했을 때의 x좌표를 차이를 계산하여 찾는다.
        selfdify=self.y-reference_point.y   #원점을 기준으로 했을 때의 y좌표를 차이를 계산하여 찾는다.

        newdifx=selfdifx*math.cos(angle)-selfdify*math.sin(angle)   #식에 따라 x방향으로 원점으로부터 떨어진 거리를 찾는다.
        newdify = selfdifx * math.sin(angle) + selfdify * math.cos(angle)   #식에 따라 y방향으로 원점으로부터 떨어진 거리를 찾는다.
        newx=newdifx+reference_point.x  #계산된 결과를 바탕으로 실제 x좌표를 계산한다.
        newy=newdify+reference_point.y  #계산된 결과를 바탕으로 실제 y좌표를 계산한다.


        return Point(newx,newy)


