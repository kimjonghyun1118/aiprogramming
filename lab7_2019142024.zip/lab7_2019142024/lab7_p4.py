inputfn=input("Data filename: ")    #filename을 str형으로 input을 받는다.

maxlength=0 #maxlength는 nested list중 가장 긴 list의 길이로 0으로 초기화한다.
with open(inputfn,'r') as file: #read모드로 inputfn을 읽어 file에 넣는다.
    for line in file:   #file을 line단위로 읽는다.
        line=line.strip()   #file의 앞뒤에 있는 공백과 줄바꿈을 제거한다.
        list=line.split(',')    #,을 기준으로 쪼개서 list라는 list에 저장한다.
        length=len(list)    #length란 list의 길이를 의미한다.
        if length>=maxlength:   #만약 list의 길이가 maxlength보다 크다면 그 길이가 maxlength가 된다.
            maxlength=length

numlist=[0]*maxlength   #numlist를 0으로 구성된 maxlength의 길이를 가진 list로 초기화한다.
sum=0   #모든 수의 합인 sum을 0으로 초기화한다.
with open(inputfn,'r') as file:     #한번더 inputfn을 read모드로 file에 불러온다.
    for line in file:   #줄 단위로 읽는다.
        line=line.strip()   #앞뒤에 있는 띄어쓰기와 줄바꿈을 없앤다.
        strlist=line.split(',') #,를 기준으로 쪼개서 strlist에 넣는다.
        intlist = []    #intlist를 비어있는 list로 초기화한다.
        for s in strlist:  #strlist에 있는 인수를 정수형으로 바꾸어 intlist에 넣는다.
            intlist.append(int(s))
        for i in range(len(intlist)):   #같은 index값인 numlist에 intlist의 값을 더해준다.
            numlist[i]=numlist[i]+intlist[i]



for j in range(len(numlist)):   #numlist에 있는 모든 수를 더한다.
    sum = sum + numlist[j]
print("Sum of all elements is",sum)
print("Column-wise summation gives ",end='')
for i in range(len(numlist)-1): #numlist의 마지막 수를 제외하고 모두 print한다.
    print(numlist[i],end=' ')

print(numlist[len(numlist)-1])  #numlist의 마지막 수를 print한다.

