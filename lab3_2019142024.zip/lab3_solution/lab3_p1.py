import stack

user_input = input("Enter parentheses and/or braces: ")

# Initialize stack
stk = stack.getStack()
valid = True    # Validity flag of given parentheses/braces string

for e in user_input:
    if e == '(' or e == '{':
        stack.push(stk, e)
    elif e == ')' or e == '}':
        top = stack.pop(stk)
        # Check matching
        if top == '(' and e == ')':
            continue
        elif top == '{' and e == '}':
            continue
        # Not matching - invalid input
        else:
            valid = False
            break

# Non-empty stack := Not closed (nested) properly
valid = stack.isEmpty(stk)

if valid:
    print("Nested properly.")
else:
    print("Not properly nested.")