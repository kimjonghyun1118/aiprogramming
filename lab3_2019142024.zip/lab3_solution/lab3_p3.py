import math

def read_points_from_file(filename):
    """Convert data text file into the list of points"""
    # Read the entire text file
    with open(filename, 'r') as f:
        s = f.read()

    # Initialize
    points = list()
    
    # Read file and add point iteratively
    s = s.split('\n')
    for _s in s[:-1]:
        ab = _s.split(', ')
        points.append([float(ab[0]), float(ab[1])])
    
    return points


def linear_interp(a, fa, b, fb, m):
    """Linear interpolation"""
    return fa + (fb - fa) * (m - a)/(b-a)


def find_index(sorted_list, x):
    """Find closest index that x would be inserted in sorted_list"""
    low = 0
    high = len(sorted_list) - 1

    # Binary search
    while low <= high:
        mid = (low + high) // 2
        if sorted_list[mid] < x:
            low = mid + 1
        elif sorted_list[mid] > x:
            high = mid - 1
        else:
            return mid

    return low


def bisectionMethod(function_file, tol):
    """Root-finding method - Bisection method"""
    # Initialize
    points = read_points_from_file(function_file)
    pa = points[0]
    pb = points[-1]
    x = [p[0] for p in points]  # List of x-values

    # Find root
    while True:
        m = (pa[0] + pb[0]) / 2
        i = find_index(x, m) - 1
        fm = linear_interp(*points[i], *points[i+1], m)
        if fm * pa[1] < 0: pb = [m, fm]
        elif fm * pb[1] < 0: pa = [m, fm]
        elif fm == 0: return m

        if abs(pa[0] - pb[0]) < tol:
            return (pa[0] + pb[0]) / 2