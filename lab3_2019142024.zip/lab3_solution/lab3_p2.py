def countAllLetters(path_to_file):
    """Count the number of each alphabet characters"""
    # Read the entire text from file
    with open(path_to_file) as f:
        s = f.read()

    data = {}   # Initial dictionary
    for c in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ':    # Case-sensitive
        n = s.count(c)
        if n > 0:   # Count only if the alphabet exists
            data[c] = n
    
    return data