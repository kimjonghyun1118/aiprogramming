def read_data(filename):
    """
    주어진 파일 이름으로부터 데이터를 읽어 리스트(1D 또는 2D)로 반환합니다.
    파일이 존재하지 않거나 형식이 잘못된 경우 예외를 발생시킵니다.
    """
    try:
        with open(filename, 'r') as file:
            data = [line.strip().split(',') for line in file]
            data = [[float(x) for x in row] for row in data]

            # 1D 배열인지 확인
            if all(len(row) == 1 for row in data):
                return [row[0] for row in data]

            # 2D 배열인지 확인
            row_lengths = set(len(row) for row in data)
            if len(row_lengths) == 1:
                return data

            # 그 외 형태는 잘못된 형식으로 간주
            raise ValueError(f"{filename} has incorrect data format")
    except FileNotFoundError:
        raise FileNotFoundError(f"{filename} not found")
    except ValueError:
        raise ValueError(f"{filename} has incorrect data format")


while True:
    filename = input("Data filename: ")
    if filename.lower() == 'q':
        break

    try:
        data = read_data(filename)
    except FileNotFoundError as e:
        print(f"Smoothing failed – {e}")
        continue
    except ValueError as e:
        print(f"Smoothing failed – {e}")
        continue





data = []

with open(filename, 'r') as file:
    for line in file:
        str_values = line.strip().split(',')
        float_values = [float(value) for value in str_values]
        data.append(float_values)


rowsize = len(data)
colsize = len(data[0])
windowsize = int(input("Window size: "))
bigrowsize=rowsize+windowsize-1
bigcolsize=colsize+windowsize-1
bigarray = [[round(0.0, 2)] * bigcolsize for _ in range(bigrowsize)]
k=int((windowsize-1)/2)


for i in range(k,bigrowsize-k):
    for j in range(k,bigcolsize-k):
        bigarray[i][j]=data[i-k][j-k]
    for j in range(k):
        bigarray[i][j]=data[i-k][0]
    for j in range(bigcolsize-k,bigcolsize):
        bigarray[i][j]=data[i-k][bigcolsize-2*k-1]
for i in range(0, k):
    for j in range(0, bigcolsize):
        bigarray[i][j]=bigarray[k][j]

for i in range(bigrowsize-k,bigrowsize):
    for j in range(0, bigcolsize):
        bigarray[i][j]=bigarray[bigrowsize-k-1][j]
val=0.0
smootharray = [[round(0.0, 2)] * colsize for _ in range(rowsize)]
for i in range(rowsize):
    for j in range(colsize):
        for p in range(windowsize):
            for q in range(windowsize):
                val=val+bigarray[i+p][j+q]
        smootharray[i][j]=val/(windowsize**2)



with open(filename, 'w') as file:
    for rowsize in smootharray:
        if isinstance(rowsize, list):
            file.write(",".join(rowsize) + "\n")
        else:
            file.write(rowsize + "\n")


    def save_data(data, filename):
        """
        주어진 데이터 리스트(1D 또는 2D)를 주어진 파일 이름으로 저장합니다.
        """
        with open(filename, 'w') as file:
            for row in data:
                if isinstance(row, list):
                    file.write(",".join(row) + "\n")
                else:
                    file.write(row + "\n")


    smoothed_filename = f"{filename.split('.')[0]}_smoothed_{windowsize}.txt"
    save_data(smootharray, smoothed_filename)
    print(f"Smoothing complete – saved as {smoothed_filename}")






