def removeExtraWhitespace(filename):
    """Pls.put your docstring here..."""

    result = filename.split('.')[0] + '_modified.txt'  #출력 파일의 끝부분에 _modified가 붙도록 한다.
    numspace = 0  #numspace란 지워진 space의 수를 나타내는 변수로, 0으로 초기화한다.


    with open(filename, 'r') as f:  #filename이라는 file을 read모드로 불러온다.
        file = f.read() #file에 그 내용을 읽어온다.


    filewriting = ''
    front = ''  # 이전 문자를 추적하여 띄어쓰기가 연속되었는지 확인
    for char in file:
        if char == ' ' and front == ' ':
            numspace += 1  # 연속된 띄어쓰기를 하나로 만들었으므로 삭제된 띄어쓰기 수 증가
        elif char != ' ' or front != ' ':
            filewriting += char  # 새로운 내용에 현재 문자를 추가
        front = char  # 현재 문자를 이전 문자로 설정

    # 출력 파일에 쓰기
    with open(result, 'w') as f:
        f.write(filewriting)

    return numspace