import operator #sort함수를 이용하여 itemgetter(0)의 index에 접근하기 위해 operator library를 import한다.
myList = {} #비어있는 List를 생성한다.
while True: #break의 조건이 걸리기 전까지 반복한다.
    fruit = input("Enter a fruit type (q to quit): ")       #fruit이라는 값을 str형으로 input을 받는다.
    if fruit == "q":    #만약 받은 fruit의 값이 "q"라면 while문을 탈출한다.
        break

    weight = int(input("Enter the weight in kg: "))     #input으로 int형으로 weight값을 받는다.

    if fruit in myList: #이 때, fruit이 myList안에 있는 값이라면 weight를 그 key에 맞는 값으로 더해준다.
        myList[fruit] += weight
    else:   #그렇지 않다면 weight는 그 fruit이라는 key에 맞는 값이 된다.
        myList[fruit] = weight

myList_items = list(myList.items()) #sort함수를 이용하기 위해 myList를 list로 변환시킨다.

# 리스트를 키를 기준으로 정렬
myList_items.sort(key=operator.itemgetter(0))   #sort함수를 사용하여 fruit을 알파벳 순으로 sort한다.

for item in myList_items:   #sort된 myList_items라는 list를 형식에 맞게 print한다.
    print(item[0], end='')
    print(", ", end='')
    print(item[1], end='')
    print("kg.")
