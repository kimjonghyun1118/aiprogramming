def copyFiles(f1, f2, f3):
    """f1와 f2라는 파일은 읽기모드로 불러오고, f3는 쓰기 모드로 불러와
    f1, f2의 순서로 f3에 그 내용을 write하는 함수"""

    try:
        a= open(str(f1), 'r')   #f1이라는 파일은 read모드로 읽어와서 b에 할당한다.
        b= open(str(f2), 'r')   #f2이라는 파일은 read모드로 읽어와서 b에 할당한다.
        c= open(str(f3), 'w')   #f3라는 파일은 write모드로 일어와서 c에 할당한다.

        c.write(a.read())   #순서에 맞게 a의 text를 읽어와서 c라는 파일에 먼저 쓴다.
        c.write(b.read())   #다음으로 b의 text를 읽어와서 c라는 파일에 적는다.



        return 0    #성공적으로 operation이 완료되면 0을 return한다.
    except:
        return -1   #exception handling으로 error가 발생하면 -1을 return한다.