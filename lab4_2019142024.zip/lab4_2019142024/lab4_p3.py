height = int(input("Display height?: "))        #height값을 int형으로 input을 받는다.
number = int(input("Up to which number to print?: "))   #number값을 int형으로 input을 받는다.

num=1   #뒤에 나올 변수들 초기화
i=0
j=0
r=0
rnum=0      #각 열에서 맨 앞에 오는 숫자를 의미한다.
rnumtemp=0
for r in range(height):     #r은 height값만큼 반복된다.
    if (r % 2 == 0):        #r이 짝수일 때와 혹수일 때 그 패턴이 달라진다.
        rnum = rnumtemp + 1 #r이 짝수일 때에는 그 수가 1씩 증가한다.
    elif (r % 2 != 0):  #r이 홀수일 때에는 계차수열의 형태로 2*r씩 증가한다.
        rnum = rnumtemp + 2 * r #계차수열 구현
    rnumtemp = rnum #일시적인 값인 rnumtemp에 rnum을 저장하여 뒤에서는 rnumtemp 값이 바뀌지 않도록 한다.
    if rnumtemp<=number:    #rnumtemp값을 각 열의 맨 앞에 출력한다.
        print(f'{rnumtemp:3}', end='')  #print할 때 3자리에 맞추어서 출력한다. 이하도 똑같다.

    #출력을 두 부분으로 나눌 수 있는데, 수들이 직각삼각형을 이룰 떄와 그 이후로 나눌 수 있다.
    i = 0   #i값 초기화
    while rnum <= number:  #rnum값이 number보다 작거나 같은 때까지만 출력한다.
        for i in range(height - r - 1): #수들이 직각삼각형을 이룰 때
            if (r % 2 == 0):    #홀수번째 열일 때와 짝수번째 열일 때 수열이 다르다.
                if (i % 2 == 0):    #r값에 따라 홀수번째 값이 바뀐다.
                    rnum = rnum + 2 * r + 1
                    if rnum > number:   #만약 rnum이 number보다 커지면 while문을 빠져나온다.
                        break
                elif (i % 2 != 0):     #계차수열을 따른다.
                    rnum = rnum + 2 * i + 2
                    if rnum > number:
                        break
                print(f'{rnum:>3}', end='')
            elif (r % 2 != 0):  #짝수번째 열일 떄에는 홀수일 때와 반대이다.
                if (i % 2 == 0):    #계차수열을 따른다.
                    rnum = rnum + 2 * i + 2
                    if rnum > number:
                        break
                elif (i % 2 != 0):  #r값에 따라 값이 바뀐다.
                    rnum = rnum + 2 * r + 1
                    if rnum > number:
                        break
                print(f'{rnum:>3}', end='')
        break  # 더 이상의 반복이 필요하지 않으므로 루프 종료

    i = 0
    while rnum <= number:   #직각삼각형 이후의 수열에 대해서 설명
        if ((height + i) % 2 != 0): #직각삼각형이 끝난 후, 늘어나는 수가 r값에 따라 증가한다.
            rnum = rnum + 1 + 2 * r
            if rnum > number:
                break
        elif ((height + i) % 2 == 0):  #그 다음으로 늘어나는 수는 r값에 따라 줄어든다.
            rnum = rnum + 2 * height - 1 - 2 * r
            if rnum > number:
                break
        print(f'{rnum:>3}', end='')
        i = i + 1   #i값을 1씩 증가시킨다.
    print('')   #줄바꿈