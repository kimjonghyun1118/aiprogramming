import numpy as np

def countLiveNeighbor(w, i, j):
    """w라는 array를 받아서 각 인수의 주변에 있는 live cell의 개수를 세서 출력한다."""
    arr=np.array(w) #w라는 array를 np array형태로 arr에 저장한다.
    biggerarr = np.pad(arr, pad_width=1, mode='constant', constant_values=0)    #arr를 padding을 통해 행열 모두 양쪽으로 1만큼 늘려 0이라는 상수를 넣는다.
    k=0 #k값을 0으로 초기화한다.
    for p in range(i, i+3): #정해진 자리에서 3*3크기의 정사각형 범위의 live cell의 개수를 센다.
        for q in range(j, j+3):
            if biggerarr[p][q]==1:  #만약 그 자리가 live cell이라면 k의 값을 1 늘린다.
                k=k+1
    if arr[i][j]==1:    #live cell의 개수를 셀 때 자신을 포함하지 않고 주변 8개의 live cell개수만 센다.
        num_of_live_cell = k-1  #만약 자신이 live cell이라면 k-1이 live cell의 개수이다.
    if arr[i][j]==0:
        num_of_live_cell=k  #만약 자신이 live cell이 아니라면 k값이 그대로 live cell의 개수가 된다.


    return num_of_live_cell