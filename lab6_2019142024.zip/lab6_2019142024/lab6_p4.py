import numpy as np
def nextCellState(W):
    """일련의 규칙에 따라 다음 live cell을 결정하여 array로 출력하는함수"""
    arr=np.array(W) #lab_p3와 동일
    h,w=W.shape
    num_of_live_cell_array=np.zeros((h,w))
    biggerarr = np.pad(arr, pad_width=1, mode='constant', constant_values=0)

    for i in range(h):
        for j in range(w):
            k=0
            for p in range(i, i+3):
                for q in range(j, j+3):
                    if biggerarr[p][q]==1:
                        k=k+1
            num_of_live_cell=0
            if arr[i][j]==1:
                num_of_live_cell = k-1
            if arr[i][j]==0:
                num_of_live_cell=k
            num_of_live_cell_array[i][j]=num_of_live_cell

    for i in range(h):
        for j in range(w):
            if num_of_live_cell_array[i][j]<2 and arr[i][j]==1:
                arr[i][j]=0 #만약 live cell인데 주변 live cell의 개수가 2보다 작다면 죽인다.
            elif 2<=num_of_live_cell_array[i][j]<=3 and arr[i][j]==1:
                arr[i][j]=1 #만약 live cell인데 주변 live cell의 개수가 2또는 3개라면 계속 살린다.
            elif 3<num_of_live_cell_array[i][j] and arr[i][j]==1:
                arr[i][j]=0 #만약 live cell인데 3개보다 많은 주변 live cell을 갖고 있다면 죽인다.
            elif num_of_live_cell_array[i][j]==3 and arr[i][j]!=1:
                arr[i][j]=1 #만약 dead cell인데 3개의 주면 live cell이 있다면 살린다.

    next_W=arr  #규칙에 따라 설정한 arr를 next_W에 할당한다.

    return next_W

