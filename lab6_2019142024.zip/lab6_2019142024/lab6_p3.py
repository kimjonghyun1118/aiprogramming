import numpy as np

def countLiveNeighborArray(W):
    """w라는 array를 받아서 각 인수의 주변의 live cell의 개수를 세서 array로 만들어 주는 함수"""
    arr=np.array(W) #W라는 array를 nparray형식으로 받는다.
    h,w=W.shape #h,w란 W의 각각 height, width를 의미한다.
    num_of_live_cell_array=np.zeros((h,w),dtype=int)    #h,w의 행열크기를 갖고 0의 int형 자료형을 가진 변수로 채운 array를 생성한다.
    biggerarr = np.pad(arr, pad_width=1, mode='constant', constant_values=0)    #padding을 통해 행열 크기를 양옆으로 1씩 늘리고 0을 채운 big array를 생성

    for i in range(h):
        for j in range(w):
            k=0
            for p in range(i, i+3): #lab6_p2의 방식과 동일하며 주변 livecell의 개수를 센다.
                for q in range(j, j+3):
                    if biggerarr[p][q]==1:
                        k=k+1
            num_of_live_cell=0
            if arr[i][j]==1:
                num_of_live_cell = k-1
            if arr[i][j]==0:
                num_of_live_cell=k
            num_of_live_cell_array[i][j]=num_of_live_cell   #센 livecell의 개수를 생성한 array의 인수로 넣어준다.



    return num_of_live_cell_array