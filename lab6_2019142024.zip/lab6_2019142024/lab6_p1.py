import numpy as np

def computeAngle(A, B, C):
    """내적의 식에서 cos값으로부터 numpy의 arccos함수를 사용하여 각을 계산한다."""
    BA=np.array(A)-np.array(B)  #BA벡터를 A좌표에서 B좌표를 빼서 계산한다.
    BC=np.array(C)-np.array(B)  #BC벡터를 C좌표에서 B좌표를 빼서 계산한다.
    innerproduct=BC[0]*BA[0]+BC[1]*BA[1]    #벡터의 내적곱을 이용하여 내적값을 계산한다.
    distanceBA=(BA[0]**2+BA[1]**2)**0.5 #BA의 길이를 계산한다.
    distanceBC=(BC[0]**2+BC[1]**2)**0.5 #BC의 길이를 계산한다.
    anglecos=innerproduct/(distanceBA*distanceBC)       #내적의 관계식을 이용하여 cos값을 산출한다.


    angle=np.arccos(anglecos)   #np의 arccos함수를 사용하여 angle값을 산출한다.
    angle=np.degrees(angle) #rad의 각을 도 단위로 바꿔준다.

    angle=round(angle,1)    #도 단위로 바꿔준 각을 소수 첫째 자리까지 반올림한다.

    return angle
