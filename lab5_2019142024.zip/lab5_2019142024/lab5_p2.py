class BinaryTree:
    """최대 2개의 하위 노드를 가질 수 있는 binarytree를 list의 형태로 표현한다."""
    def __init__(self, root_e):
        """ Method to construct a BinaryTree object """
        self.nodes = [root_e]   #root노드를 가장 먼저 list에 넣는다.

    def insert(self, e, parent, pos):
        """e라는 하위 노드를 pos값에 따라 parent노드의 왼쪽 또는 오른쪽에 추가한다."""
        if e in self.nodes: #이미 e가 list안에 존재한다면, 다음과 같은 에러 메시지를 출력한다.
            print("Insertion refused: Node '{}' already exists".format(e))
        elif parent not in self.nodes:  #만약 parent노드가 list에 존재하지 않는다면, 다음과 같은 에러 메시지를 출력한다.
            print("Insertion refused: Node '{}' does not exist".format(parent))

        else:
            i=self.nodes.index(parent)  #i를 list에서 몇번째 index인지 찾아 할당한다.
            #만약 추가해야 할 하위 노드의 위치가 list의 길이 안의 위치일 때
            if 2*i+2<len(self.nodes):
                if (pos=='l')&(self.nodes[2*i+1]!=None):    #만약 pos이 left인데 그 위치인 [2i+1]가 None이 아닐경우 다음과 같은 에러 메시지 출력
                    print("Insertion refused: Left child of node '{}' already occupied by ".format(parent), end='')
                    print("'{}'".format(self.nodes[2*i+1]))
                elif (pos=='r')&(self.nodes[2*i+2]!=None):  #만약 pos가 right인데 그 위치인 [2i+2]가 비어있지 않은 경우 다음과 같은 에러 메시지 출력
                    print("Insertion refused: Right child of node '{}' already occupied by ".format(parent), end='')
                    print("'{}'".format(self.nodes[2*i+2]))
                elif (pos == "l") & (self.nodes[2 * i + 1] == None):    #만약 pos이 left인데 그 위치인 [2i+1]가 비어 있을 경우 그 자리에 e를 삽입
                    self.nodes[2*i+1]=e
                elif (pos == 'r') & (self.nodes[2 * i + 2] == None):    #만약 pos이 right인데 그 위치인 [2i+2]가 비어 있을 경우 그 자리에 e를 삽입
                    self.nodes[2*i+2]=e
            else:
                if (pos == "l"):
                    while len(self.nodes) < 2*i+2:  #self.node[2*i]까지는 None으로 채운다.
                        self.nodes.append(None)
                    self.nodes[2*i+1] = e   #self.node[2*i+1]에 e를 삽입한다.
                elif (pos == 'r'):
                    while len(self.nodes) < 2*i+3:  #self.node[2*i+1]까지는 None으로 채운다.
                        self.nodes.append(None)
                    self.nodes[2*i+2] = e   #self.node[2*i+2]에 e를 삽입한다.


    def isLeaf(self, e):
        """e node가 leaf node인지를 확인한다."""
        if e not in self.nodes: #만약 e가 list안에 없을 경우 다음과 같은 에러 메시지 출력
            print("Error: Node '{}' does not exist".format(e))
            return None
        elif e in self.nodes:   #만약 e가 list안에 있을 경우
            i=self.nodes.index(e)   #e가 list안에서 어떤 index인지 찾는다.
            if 2 * i + 2 < len(self.nodes): #하위 노드의 위치가 list 길이보단 작을 때
                if (self.nodes[2*i+1]==None)&(self.nodes[2*i+2]==None): #그리고 l와 r위치의 list가 모두 None일 경우 leaf노드임을 의미
                    return True
                else:
                    return False
            else:    #하위 노드의 위치가 list 길이보단 클 때는 항상 leaf 노드임을 의미
                return True


    def delete(self, e):
        """e 노드를 찾아 삭제한다."""
        if e in self.nodes and self.isLeaf(e):  #만약 e가 list안에 있고 leafnode일 경우
            i = self.nodes.index(e) #i는 e의 list에서의 index를 의미
            self.nodes[i]=None  #e를 None으로 바꾸어줌
            while self.nodes and self.nodes[-1] is None:    #마지막 값이 None이면 제거시킴
                self.nodes.pop()

        elif e not in self.nodes:   #만약 e가 list안에 없다면 다음과 같은 에러 메시지 출력
            print("Deletion refused: Node '{}' does not exist".format(e))
        elif self.isLeaf(e)==False: #만약 e가 leaf node가 아니라면 다음과 같은 에러 메시지 출력
            print("Deletion refused: Node '{}' is not a leaf node".format(e))



    def editNode(self, e_old, e_new):
        """e_old node를 찾아서 e_new로 수정한다."""

        if e_old not in self.nodes: #만약 e_old가 list안에 존재하지 않는다면 다음과 같은 에러 메시지를 출력한다.
            print("Edit refused: Node '{}' does not exist".format(e_old))
        elif e_new in self.nodes:   #만약 e_new가 이미 list안에 존재한다면 다음과 같은 에러 메시지를 출력한다.
            print("Edit refused: Node '{}' already exists".format(e_new))
        else:   #그렇지 않다면 e_old를 e_new로 수정한다.
            i = self.nodes.index(e_old) #i는 e_old의 list안에서의 index를 의미한다.
            self.nodes[i]=e_new

    def numOfChild(self, e):
        """e의 하위 노드의 개수를 센다."""
        if e not in self.nodes:     #만약 e가 list안에 존재하지 않는다면 다음과 같은 에러 메시지를 출력한다.
            print("Error: Node '{}' does not exist".format(e))
            return None
        else:
            i = self.nodes.index(e) #i는 e의 list안에서의 index를 의미한다.
            lowernode = 0   #하위 노드의 개수를 0개로 초기화한다.
            if 2 * i + 1 < len(self.nodes) and self.nodes[2 * i + 1] is not None:   #만약 l의 하위 노드의 위치가 비어있지 않다면 lowernode값을 1 늘린다.
                lowernode =lowernode+ 1
            if 2 * i + 2 < len(self.nodes) and self.nodes[2 * i + 2] is not None:   #만약 r의 하위 노드의 위치가 비어있지 않다면 lowernode값을 1 늘린다.
                lowernode =lowernode+ 1

            return lowernode

    def isFull(self):
        """full binary tree인지 확인한다."""
        k=0 #k값을 0으로 초기화
        for i in range(len(self.nodes)):    #list안에 있는 값들에 대하여 모두 확인하다.
            if 2*i+1<=len(self.nodes)-1 and 2*i+2<=len(self.nodes)-1:   #l,r의 위치의 하위 노드 위치 모두 list의 길이보다 작을 때
                if self.nodes[2*i+1] is None and self.nodes[2*i+2] is None: #l,r의 하위 노드 모두 None일 때 k값 유지
                    k=k
                elif self.nodes[2*i+1] is not None and self.nodes[2*i+2] is not None:#l,r의 하위 노드 모두 None이 아닐 때 k값 유지
                    k=k
                elif self.nodes[2 * i + 1] is None and self.nodes[2 * i + 2] is not None:#l,r의 하위 노드 중 하나만 None일 때 k값에 1 더하기
                    k = k+1
                elif self.nodes[2 * i + 1] is not None and self.nodes[2 * i + 2] is None:#l,r의 하위 노드 중 하나만 None일 때 k값에 1 더하기
                    k = k+1
            elif 2*i+1==len(self.nodes)-1:  #만약 l의 위치의 하위 노드가 list의 마지막일 때는 binary tree가 아님
                return False


        if k==0:    #k가 0일 때(l,r 위치의 하위 노드 모두 list의 길이보다 클 때 포함)full binary tree이다.
            return True
        else:
            return False







    def height(self):
        """Height of the tree"""
        h = 1
        while True:
            if len(self.nodes) <= 2 ** h - 1:
                break
            h += 1
        return h

    def __str__(self):
        """String representation"""
        h = self.height()
        lt = self.nodes[:]

        # Remove trailing empty nodes
        while True:
            if lt[-1] is not None:
                break
            del lt[-1]

        # Replace empty node representation
        for i in range(len(lt)):
            if self.nodes[i] is None:
                lt[i] = '\u00B7'

        ret = lt[0]
        for d in range(1, h):
            ret += '\n' + ('\u00B7' * (2 ** (h - d) - 1)).join(lt[2 ** d - 1:2 ** (d + 1) - 1])
        return ret

    def __remove_trailing_none(self):
        """Remove all trailing None elements from list"""
        while True:
            if self.nodes[-1] is not None:
                break
            del self.nodes[-1]

