import math
try:
    from lab5_p1 import Fraction
except ImportError:
    pass

class Polynomial:
    """다항식의 곱,덧셈, 뺼셈, 미적분 등 다양한 연산을 포함하여 표현"""
    def __init__(self, coefficients: list):
        """Initializes the polynomial with a list of integer or Fraction coefficients."""
        self.coefficients = coefficients
        ### Solution version below
        # self.coefficients = []
        # for c in coefficients:
        #     if isinstance(c, int):
        #         self.coefficients.append(Fraction(c, 1))
        #     elif isinstance(c, Fraction):
        #         self.coefficients.append(c)

    def __add__(self, other):
        """다항식끼리의 덧셈"""
        if len(self.coefficients)>= len(other.coefficients):    #self의 다항식의 길이가 더 길거나 같을 때
            result = [None] *len(self.coefficients) #결과값의 길이는 self의 다항식의 길이와 같다.
            for i in range(len(other.coefficients)):    #other의 다항식의 길이만큼 반복
                result[i]=self.coefficients[i]+other.coefficients[i]    #두 coefficient값을 더한 값
            for i in range(len(other.coefficients),len(self.coefficients)): #나머지 길이동안 반복
                result[i]=self.coefficients[i]  #result와 self의 coefficient가 같음

        elif len(self.coefficients)< len(other.coefficients):   #other의 다항식의 길이가 더 길 때
            result = [None] *len(other.coefficients)
            for i in range(len(self.coefficients)):
                result[i]=self.coefficients[i]+other.coefficients[i]
            for i in range(len(self.coefficients),len(other.coefficients)):
                result[i]=other.coefficients[i]

        return Polynomial(result)

    def __sub__(self, other):
        """다항식끼리의 뺄셈"""
        if len(self.coefficients)>= len(other.coefficients):    #self의 다항식의 길이가 더 길거나 같을 때
            result = [None] *len(self.coefficients) #결과값의 길이는 self의 다항식의 길이와 같다.
            for i in range(len(other.coefficients)):    #other의 다항식의 길이만큼 반복
                result[i]=self.coefficients[i]-other.coefficients[i]    #self에서 other의 coefficient값을 뺸 값
            for i in range(len(other.coefficients),len(self.coefficients)): #나머지 길이동안 반복
                result[i]=self.coefficients[i]  #result와 self의 coefficient가 같음


        elif len(self.coefficients)< len(other.coefficients):   #other의 다항식의 길이가 더 길 때
            result = [None] *len(other.coefficients)
            for i in range(len(self.coefficients)):
                result[i]=self.coefficients[i]-other.coefficients[i]
            for i in range(len(self.coefficients),len(other.coefficients)):
                result[i]=-other.coefficients[i]

        return Polynomial(result)

    def __mul__(self, other):
        """다항식끼리의 곱셈"""
        result = [0] * ((len(other.coefficients)-1)*(len(self.coefficients)-1)+1)   #곱한 다항식의 길이는 최고차항끼리의 곱에 1을 더한 값과 같음
        for i in range((len(other.coefficients)-1)*(len(self.coefficients)-1)+1):   #곱한 다항식의 길이만큼 반복
            for j in range(i):  #j는 i만큼 반복
                if j<len(self.coefficients) and i-j<len(other.coefficients):
                    result[i]=result[i]+self.coefficients[j]*other.coefficients[i-j]    #곱은 합이 i가 되도록 하는 항들의 coefficient의 곱들의 합으로 이루어짐
                else:
                    pass

        return Polynomial(result)

    def derivative(self):
        """다항식의 미분"""
        result=[0]*(len(self.coefficients)-1)   #미분된 result의 길이는 self보다 1 작아짐
        for i in range(1,len(self.coefficients)):
            result[i-1]=self.coefficients[i]*i  #self 제곱항과 coefficient를 곱한 값이 result의 i-1번째 항이 됨(차수가 하나 줄기 때문이다.)
        return Polynomial(result)


    def integral(self, C=0):
        """다항식의 적분"""
        result=[0]*(len(self.coefficients)+1)   #적분된 result의 길이는 self보다 1 길어짐
        result[0]=0 #적분상수는 0으로 통일
        for i in range(1,len(self.coefficients)+1):
            f1 = Fraction(1, i) #faction을 이용하여 제곱항의 역수를 곱해줌
            result[i]=self.coefficients[i-1]*f1 #위에서 구한 제곱항의 역수와 coefficient를 곱한 값들이 result의 차수가 하나 커진 coefficient이다.
        return Polynomial(result)

    def evaluate(self, x: int):
        """Return f(x) where f is self polynomial"""
        result = 0
        for i, coeff in enumerate(self.coefficients):
            result += coeff * (x ** i)
        return result

    def __str__(self):
        """String representation of polynomial equation"""
        terms = []
        for i, coeff in enumerate(self.coefficients):
            if coeff != 0:
                if i == 0:
                    terms.append(f"{coeff}")
                elif i == 1:
                    terms.append(f"{coeff}*x")
                else:
                    terms.append(f"{coeff}*x^{i}")
        return " + ".join(terms).replace('+ -', '- ') if terms else "0"

