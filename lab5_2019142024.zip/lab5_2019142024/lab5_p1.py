class Fraction(object):
    """Class to represent a number as a fraction"""

    def __init__(self, n, d):
        """ Method to construct a Fraction object """
        if type(n) != int or type(d) != int:  # Check that n and d are of type int
            raise ValueError('requires type int')
        if d <= 0:
            raise ZeroDivisionError('requires positive integer denominator')
        # If we get here, n and d are ok => initialize Fraction:
        self.num = n
        self.denom = d
        self.reduce()

    ### Your work begins here ...

    def reduce(self):
        """Reduces self to simplest terms. This is done by dividing both
        numerator and denominator by their greatest common divisor (GCD)."""
        if (self.num != 0) & (self.denom != 1):     #만약 분자도 0이 아니고 분모도 1이 아닌 분수일 경우
            gcd = self.__gcd(self.num, self.denom)  #분자와 분모의 gcd를 구한다.
            self.num //= gcd    #분자와 분모를 모두 gcd로 나눠주어 간단히 한다.
            self.denom //= gcd

    def __str__(self):
        """ Returns a string representation of the fraction object (self) """
        if self.denom == 1: #만약 분모가 1이라면
            return str(self.num)    #/를 사용하지 않고 분자만을 정수 형태로 출력한다.
        elif self.num == 0: #만약 분자가 0이라면
            return str(self.num)    #마찬가지로/를 사용하지 않고 0인 분자를 출력한다.
        else:   #그렇지 않은 분수의 경우
            return str(self.num) + '/' + str(self.denom)  # #분자를 출력하고, /를 출력한 다음, 분모를 출력한다.

    def __add__(self, other):
        """ Returns new Fraction representing self + other """
        if isinstance(other, int):  #만약 other의 자료형이 int라면
            new_num = self.num + other * self.denom #더하기의 경우 self의 분자에 정수와 self의 분모를 곱하여 더한 값을 분자로 갖는다.
            new_denom = self.denom  #분모는 그대로이다.
            return Fraction(new_num, new_denom)
        elif isinstance(other, Fraction):   #만약 other의 자료형이 fraction이라면
            new_num = self.num * other.denom + other.num * self.denom   #분자와 상대의 분모를 곱하여 더한 값이 결과값의 분자가 된다.
            new_denom = self.denom * other.denom    #분모는 두 분모를 곱한 값을 갖는다.
            return Fraction(new_num, new_denom)

    # Modify this method.

    def __mul__(self, other):
        """ Returns new Fraction representing self * other """
        if isinstance(other, int):  #만약 other의 자료형이 정수라면
            new_num = self.num * other  #self의 분자와 other을 곱한 값이 결과값의 분자이다.
            new_denom = self.denom  #분모는 self의 분모를 그대로 갖는다.
            return Fraction(new_num, new_denom)
        elif isinstance(other, Fraction):   #other의 자료형이 fraction일 경우
            new_num = self.num * other.num  #self의 분자와 other의 분자를 곱한다.
            new_denom = self.denom * other.denom    #self의 분모와 other의 분모를 곱한다.
            return Fraction(new_num, new_denom)

    def __sub__(self, other):
        """ Returns new Fraction representing self - other """
        if isinstance(other, int):  #만약 other의 자료형이 정수형일 경우
            new_num = self.num - other * self.denom #self의 분자에서 other과 self의 분모를 곱한값을 뺀다.
            new_denom = self.denom      #분모의 경우 self의 분모를 그대로 갖는다.
            return Fraction(new_num, new_denom)
        elif isinstance(other, Fraction):   #other의 자료형이 fraction일 경우
            new_num = self.num * other.denom - other.num * self.denom   #self의 분자와 other의 분모를 곱한 값에서 self의 분모와 other의 분자를 곱한 값을 뺀다.
            new_denom = self.denom * other.denom    #두 분모를 곱한 값을 결과의 분모로 갖는다.
            return Fraction(new_num, new_denom)

    def __truediv__(self, other):
        """ Returns new Fraction representing self / other """
        if isinstance(other, int):  #만약 other의 자료형이 정수형일 경우
            new_num = self.num  #분자는 그대로이다.
            new_denom = self.denom * other  #분모의 경우 self의 분모와 other을 곱한값을 갖는다.
            return Fraction(new_num, new_denom)
        elif isinstance(other, Fraction):   #만약 other의 자료형이 fraction일 경우
            new_num = self.num * other.denom    #나눗셈은 역수를 취해서 곱한 것과 동일하다.
            new_denom = self.denom * other.num  #self의 분모와 other의 num을 곱하여 분모를 결정한다.
            return Fraction(new_num, new_denom)

    def __lt__(self, other):
        """other이 self의 값보다 더 크다면 True를 출력하고 그렇지 않다면 False를 출력한다."""
        if isinstance(other, int):
            #other의 자료형이 정수일 때
            if self.num < other * self.denom:   #self의 분자와 other과 self의 분모의 곱을 비교한다.
                return True
            else:
                return False
        elif isinstance(other, Fraction):
            #other의 자료형이 Fraction일 때
            if self.num * other.denom < other.num * self.denom: #self의 분자와 other의 분모의 곱, 그리고 self의 분모와 other의 분자의 곱을 비교한다.
                return True
            else:
                return False

    def __le__(self, other):
        """other이 self의 값보다 더 크거나 같다면 True를 출력하고 그렇지 않다면 False를 출력한다."""
        if isinstance(other, int):
            #other의 자료형이 int일 때
            if self.num <= other * self.denom:  #self의 분자와 other과 self의 분모의 곱을 비교한다.
                return True
            else:
                return False
        elif isinstance(other, Fraction):
            # other의 자료형이 Fraction일 때
            if self.num * other.denom <= other.num * self.denom:    #self의 분자와 other의 분모의 곱, 그리고 self의 분모와 other의 분자의 곱을 비교한다.
                return True
            else:
                return False

    def __gt__(self, other):
        """other이 self의 값보다 더 작다면 True를 출력하고 그렇지 않다면 False를 출력한다."""
        if isinstance(other, int):
            # other의 자료형이 int일 때
            if self.num > other * self.denom:   #self의 분자와 other과 self의 분모의 곱을 비교한다.
                return True
            else:
                return False
        elif isinstance(other, Fraction):
            # other의 자료형이 Fraction일 때
            if self.num * other.denom > other.num * self.denom: #self의 분자와 other의 분모의 곱, 그리고 self의 분모와 other의 분자의 곱을 비교한다.
                return True
            else:
                return False

    def __ge__(self, other):
        """other이 self의 값보다 더 작거나 같다면 True를 출력하고 그렇지 않다면 False를 출력한다."""
        if isinstance(other, int):
            # other의 자료형이 int일 때
            if self.num >= other * self.denom:  #self의 분자와 other과 self의 분모의 곱을 비교한다.
                return True
            else:
                return False
        elif isinstance(other, Fraction):
            # other의 자료형이 Fraction일 때
            if self.num * other.denom >= other.num * self.denom:    #self의 분자와 other의 분모의 곱, 그리고 self의 분모와 other의 분자의 곱을 비교한다.
                return True
            else:
                return False

    def __eq__(self, other):
        """other이 self의 값과 같다면 True를 출력하고 그렇지 않다면 False를 출력한다."""
        if isinstance(other, int):
            # other의 자료형이 int일 때
            if self.num == other * self.denom:  #self의 분자와 other과 self의 분모의 곱을 비교한다.
                return True
            else:
                return False
        elif isinstance(other, Fraction):
            # other의 자료형이 Fraction일 때
            if self.num * other.denom == other.num * self.denom:    #self의 분자와 other의 분모의 곱, 그리고 self의 분모와 other의 분자의 곱을 비교한다.
                return True
            else:
                return False

    ### Your work ends here ...
    # ----- You don't have to modify below
    def __gcd(self, _a, _b):
        """Get GCD of _a and _b"""
        a, b = abs(_a), abs(_b)
        if b > a: a, b = b, a
        while b != 0:
            [a, b] = [b, a % b]
        if a == 0: a = 1
        return a

    def __neg__(self):
        """Negation"""
        # Returns -self
        return Fraction(-self.num, self.denom)

    __radd__ = __add__
    __rmul__ = __mul__

    def __rsub__(self, other):
        """Right subtraction"""
        # Handles int - Fraction
        if isinstance(other, int):
            return Fraction(other, 1).__sub__(self)
        elif isinstance(other, Fraction):
            return other.__sub__(self)
        else:
            raise ValueError('requires type int or Fraction')

    def __rtruediv__(self, other):
        """Right division"""
        # Handles int / Fraction
        if isinstance(other, int):
            return Fraction(other, 1).__truediv__(self)
        elif isinstance(other, Fraction):
            return other.__truediv__(self)
        else:
            raise ValueError('requires type int or Fraction')

    def __pow__(self, other):
        """Power; Fraction ** int"""
        if isinstance(other, int):
            if other == 0:
                return Fraction(1, 1)
            else:
                ret = self
                for _ in range(abs(other) - 1):
                    ret = ret.__mul__(self)
                if other < 0:
                    ret = ret.__rtruediv__(1)
            return ret
        else:
            raise ValueError('requires type int')

